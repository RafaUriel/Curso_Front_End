# Curso Frontend Practitioner

## Contenido:

1. Clase 1 - Introducción a HTMl y CSS
2. Clase 2 -  
3. Clase 3 - Instalación de Node.Js
4. Clase 4 - Creando componentes
5. Clase 5 - Iterando Arrays
6. Clase 6 - 
7. Clase 7 - Crud de personal
8. Clase 8 -

## Clase 1 - Introducción a HTMl y CSS
