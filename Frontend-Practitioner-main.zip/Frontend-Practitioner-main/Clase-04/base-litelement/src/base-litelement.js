import { BaseLitelement } from './BaseLitelement.js';

customElements.define('base-litelement', BaseLitelement);
