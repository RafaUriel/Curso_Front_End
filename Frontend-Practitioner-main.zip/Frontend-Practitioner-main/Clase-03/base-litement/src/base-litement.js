import { BaseLitement } from './BaseLitement.js';

customElements.define('base-litement', BaseLitement);
